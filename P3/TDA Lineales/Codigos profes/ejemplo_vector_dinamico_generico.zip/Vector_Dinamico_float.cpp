#include "Vector_Dinamico.h"
#include "Vector_Dinamico.tpp"


//Forzamos la instanciación de la clase Vector_Dinamico con el tipo base float,
//que se usa en el programa
template class Vector_Dinamico<float>;
